async function login() {

    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    const res = await fetch("/api/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            username,
            password
        })
    });

    const data = await res.json();

    if (data.success) {

        localStorage.setItem("loggedIn", "true");
        localStorage.setItem("username", username);
        window.location.href = "profile.html";

    } else {

        document.getElementById("message").innerText =
            "Verkeerde gebruikersnaam of wachtwoord";

    }
}