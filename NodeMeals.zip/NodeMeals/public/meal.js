const params = new URLSearchParams(window.location.search);
const id = params.get("id");

async function loadMeal() {

    const res = await fetch(`/api/meals/${id}`);
    const meal = await res.json();

    document.getElementById("meal").innerHTML = `
        <img src="${meal.image}" width="400">

        <h1>${meal.name}</h1>

        <p><b>Kcal:</b> ${meal.kcal}</p>
        <p><b>Eiwit:</b> ${meal.protein}g</p>

        <p>${meal.description}</p>

        <a href="${meal.video}" target="_blank">
            Bekijk recept video
        </a>
    `;
}

loadMeal();