window.onload = function () {

    const username = localStorage.getItem("username");

    const loginBtn = document.getElementById("loginBtn");
    const registerBtn = document.getElementById("registerBtn");
    const logoutBtn = document.getElementById("logoutBtn");
    const userText = document.getElementById("userText");

    if (username) {

        userText.innerText = `Welkom ${username}`;

        loginBtn.style.display = "none";
        registerBtn.style.display = "none";
        logoutBtn.style.display = "block";

    } else {

        userText.innerText = "Niet ingelogd";

        loginBtn.style.display = "block";
        registerBtn.style.display = "block";
        logoutBtn.style.display = "none";
    }
};

    function logout() {
        localStorage.removeItem("username");
        window.location.href = "profile.html";
    }