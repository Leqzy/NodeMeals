async function loadMeals() {
    const type = document.getElementById("typeFilter").value;
    const category = document.getElementById("categoryFilter").value;

    let url = "/api/meals?";

    if (type) url += `type=${type}&`;
    if (category) url += `category=${category}`;

    const res = await fetch(url);
    const data = await res.json();

    const container = document.getElementById("result");
    container.innerHTML = "";

    data.forEach(meal => {
        container.innerHTML += `
            <div class="card" onclick="window.location.href='meal.html?id=${meal.id}'">
                <img src="${meal.image}" />
                <h3>${meal.name}</h3>
            </div>
        `;
    });
}

async function showMeal(id) {
    const res = await fetch(`/api/meals/${id}`);
    const meal = await res.json();

    document.getElementById("detail").innerHTML = `
        <div class="detail">
            <img src="${meal.image}" />
            <h2>${meal.name}</h2>
            <p><b>kcal:</b> ${meal.kcal}</p>
            <p><b>eiwitten:</b> ${meal.protein}g</p>
            <p>${meal.description}</p>
             <a href="${meal.video}" target="_blank">
                🎥 Bekijk video
            </a>
            </ul>
        </div>
    `;
}

// auto load
loadMeals();