const express = require("express");
const app = express();

const fs = require("fs");

const meals = require("./data/meals.json");
const users = require("./data/users.json");

app.use(express.static("public"));
app.use(express.json());


// GET alle meals (met filters)
app.get("/api/meals", (req, res) => {
    const { type, category } = req.query;

    let filtered = meals;

    if (type) {
        filtered = filtered.filter(m => m.type === type);
    }

    if (category) {
        filtered = filtered.filter(m => m.category === category);
    }

    res.json(filtered);
});

app.get("/api/meals/:id", (req, res) => {
    const meal = meals.find(m => m.id == req.params.id);
    res.json(meal);
});

//PROFILE//
app.get("/api/profile", (req, res) => {

    // Simuleer ingelogde gebruiker
    const user = users[0];
    res.json(user);
});

//LOGIN//
app.post("/api/login", (req, res) => {

    const { username, password } = req.body;

    const user = users.find(
        u => u.username === username &&
             u.password === password
    );

    if (user) {
        res.json({ success: true });
    } else {
        res.json({ success: false });
    }

});

//REGISTER//
app.post("/api/register", (req, res) => {

    const { username, password } = req.body;

    const existingUser = users.find(
        u => u.username === username
    );

    if (existingUser) {

        return res.json({
            message: "Gebruiker bestaat al"
        });

    }

    const newUser = {
        id: users.length + 1,
        username,
        password
    };

    users.push(newUser);

    fs.writeFileSync(
        "./data/users.json",
        JSON.stringify(users, null, 4)
    );

    res.json({
        message: "Account aangemaakt"
    });

});

app.listen(3000, () => {
    console.log("Server draait op http://localhost:3000");
});